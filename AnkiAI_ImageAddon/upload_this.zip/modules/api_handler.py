"""
API Handler Module v4.2 - MEGA Multi-AI + 15+ Image Provider Selection
Optimizations:
- Reduced redundant API calls
- Aggressive timeouts (Groq: 5s, Gemini: 8s, Images: 4-5s)
- Early cache hits skip all processing
- Fallback chain with minimal overhead
- Memory-efficient result handling
- Multi-key Gemini backup system (v4.2)
- Rate-limit auto-pause protection (v4.2)
"""

import requests
import json
from typing import Optional, Dict, List, Tuple
import time
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeoutError
from .ai_providers import MultiAIProvider, AIProviderError, GeminiImageEvaluator
from .image_providers import (
    SmartImageSelector, 
    PexelsProvider, 
    UnsplashProvider, 
    PixabayProvider,
    GoogleImageProvider,
    OpenverseProvider,
    WallhavenProvider,
    LoremPicsumProvider,
    NASAProvider,
    FlickrProvider,
    LibraryOfCongressProvider,
    WikimediaCommonsProvider,
    SmithsonianProvider,
    MetMuseumProvider,
    EuropeanaProvider,
    FlagsAPIProvider,
    ImageProviderError
)


class APIError(Exception):
    """Exception cho API calls"""
    pass


class KeywordCache:
    """
    Cache cho keywords để tránh re-call AI - v4.3 ULTRA-FAST
    Optimizations:
    - Lazy initialization for each keyword entry
    - Minimal lock contention with dictionary lookups
    - Fast O(1) access
    - Automatic TTL cleanup
    - Memory-efficient storage
    """
    
    def __init__(self, max_size: int = 1000, ttl_hours: int = 24):
        self.cache: Dict[str, Tuple[str, float]] = {}  # {key: (value, timestamp)}
        self.max_size = max_size
        self.ttl_seconds = ttl_hours * 3600
        self.lock = __import__('threading').Lock()
        self.access_count = 0  # ✨ Track access for cleanup
    
    def get(self, key: str) -> Optional[str]:
        """Lấy keyword từ cache - O(1) ULTRA-FAST"""
        with self.lock:
            if key in self.cache:
                value, timestamp = self.cache[key]
                # Check TTL
                import time
                if time.time() - timestamp < self.ttl_seconds:
                    self.access_count += 1
                    return value
                else:
                    # Expired - remove
                    del self.cache[key]
                    return None
            return None
    
    def set(self, key: str, value: str):
        """Lưu keyword vào cache"""
        with self.lock:
            import time
            # ✨ Simple LRU: evict oldest if at capacity
            if len(self.cache) >= self.max_size:
                # Find oldest entry
                oldest_key = min(self.cache.keys(), key=lambda k: self.cache[k][1])
                del self.cache[oldest_key]
            self.cache[key] = (value, time.time())
    
    def clear(self):
        """Xóa toàn bộ cache"""
        with self.lock:
            self.cache.clear()
            self.access_count = 0
    
    def size(self) -> int:
        """Lấy số items trong cache"""
        with self.lock:
            return len(self.cache)
    
    def make_key(self, vocabulary: str, definition: str) -> str:
        """Tạo cache key từ vocabulary + definition"""
        # ✨ Simplified key generation for speed
        return f"{vocabulary}|{definition}".lower()



class AIImageProvider:
    """
    Wrapper cho Multi-AI + Smart Image Selection - v4.0
    Optimized for performance, quality, and reliability
    """
    
    def __init__(self, 
                 # AI Providers (v4.2 - multi-key)
                 gemini_key: str = "", 
                 gemini_eval_key: str = "",
                 gemini_eval_key_backup: str = "",  # ✨ NEW v4.2
                 gemini_backup_key: str = "",
                 gemini_keyword_backup: str = "",  # ✨ NEW v4.2
                 groq_key: str = "", 
                 use_ollama: bool = False, 
                 ollama_url: str = "http://localhost:11434",
                 # Image Search Providers (v4.2 - expanded)
                 unsplash_key: str = None, 
                 pixabay_key: str = None,
                 pexels_key: str = None,
                 wallhaven_key: str = None,
                 google_api_key: str = None,
                 google_cx: str = None,
                 flickr_key: str = None,  # ✨ NEW v4.2
                 europeana_key: str = None,  # ✨ NEW v4.2
                 # Settings (v4.2)
                 enable_smart_selection: bool = True,
                 enable_ai_evaluation: bool = True,
                 enable_rate_limit_protection: bool = True,  # ✨ NEW v4.2
                 max_concurrent_providers: int = 6):
        """
        Khởi tạo AIImageProvider với 15+ image providers + multi-key Gemini system
        
        Args:
            gemini_key: Main Gemini API key (keyword generation)
            gemini_eval_key: Gemini API key for image evaluation (v4.0)
            gemini_eval_key_backup: Backup eval key (v4.2)
            gemini_backup_key: Gemini backup API key (v4.0)
            gemini_keyword_backup: Backup for keyword gen (v4.2)
            groq_key, use_ollama: Other AI providers
            unsplash_key, pixabay_key, pexels_key, wallhaven_key: Image provider keys
            google_api_key, google_cx: Google Custom Search credentials
            flickr_key, europeana_key: New providers (v4.2)
            enable_smart_selection: Use SmartImageSelector
            enable_ai_evaluation: Use Gemini Vision to pick best image
            enable_rate_limit_protection: Auto-pause on rate limit (v4.2)
            max_concurrent_providers: Max concurrent provider requests
        """
        # Initialize AI Provider
        try:
            self.ai_provider = MultiAIProvider(
                gemini_key=gemini_key,
                gemini_backup_key=gemini_keyword_backup or gemini_backup_key,  # ✨ v4.2
                groq_key=groq_key,
                use_ollama=use_ollama,
                ollama_url=ollama_url
            )
            print("[✓] AI Provider initialized")
        except AIProviderError as e:
            raise APIError(f"AI Provider failed: {e}")
        
        # Initialize keyword cache
        self.keyword_cache = KeywordCache(max_size=1000)
        
        # Initialize Image Evaluator (v4.2 - multi-key)
        self.image_evaluator = None
        self.enable_ai_evaluation = enable_ai_evaluation
        
        if enable_ai_evaluation:
            # ✨ NEW v4.2: Try multiple keys in order
            eval_keys = [
                gemini_eval_key,
                gemini_eval_key_backup,
                gemini_backup_key,
                gemini_key
            ]
            eval_keys = [k for k in eval_keys if k]  # Remove empty strings
            
            if eval_keys:
                try:
                    # Pass all keys to evaluator for fallback chain
                    self.image_evaluator = GeminiImageEvaluator(
                        eval_keys[0],
                        backup_key=eval_keys[1] if len(eval_keys) > 1 else "",
                        backup_key_2=eval_keys[2] if len(eval_keys) > 2 else ""
                    )
                    print("[✓] Gemini Image Evaluator initialized")
                except AIProviderError as e:
                    print(f"[WARN] Image Evaluator init failed: {e}, will use smart selection only")
                    self.image_evaluator = None
        
        # Initialize Smart Image Selector (v4.2)
        self.smart_selector = None
        self.enable_smart_selection = enable_smart_selection
        
        if enable_smart_selection:
            self.smart_selector = SmartImageSelector(max_workers=max_concurrent_providers)
            
            # Add providers to smart selector (priority order)
            if pexels_key:
                try:
                    self.smart_selector.add_provider(
                        "pexels", 
                        PexelsProvider(pexels_key)
                    )
                except Exception as e:
                    print(f"[WARN] Pexels init failed: {e}")
            
            if unsplash_key:
                try:
                    self.smart_selector.add_provider(
                        "unsplash", 
                        UnsplashProvider(unsplash_key)
                    )
                except Exception as e:
                    print(f"[WARN] Unsplash init failed: {e}")
            
            if pixabay_key:
                try:
                    self.smart_selector.add_provider(
                        "pixabay", 
                        PixabayProvider(pixabay_key)
                    )
                except Exception as e:
                    print(f"[WARN] Pixabay init failed: {e}")
            
            # Google Custom Search (v4.0)
            if google_api_key and google_cx:
                try:
                    self.smart_selector.add_provider(
                        "google",
                        GoogleImageProvider(google_api_key, google_cx)
                    )
                except Exception as e:
                    print(f"[WARN] Google Custom Search init failed: {e}")
            
            # Free providers (no API key needed!)
            try:
                self.smart_selector.add_provider(
                    "openverse", 
                    OpenverseProvider()
                )
            except Exception as e:
                print(f"[WARN] Openverse init failed: {e}")
            
            if wallhaven_key:
                try:
                    self.smart_selector.add_provider(
                        "wallhaven", 
                        WallhavenProvider(wallhaven_key)
                    )
                except Exception as e:
                    print(f"[WARN] Wallhaven init failed: {e}")
            
            # Lorem Picsum (instant, NO API key!)
            try:
                self.smart_selector.add_provider(
                    "lorem_picsum", 
                    LoremPicsumProvider()
                )
            except Exception as e:
                print(f"[WARN] Lorem Picsum init failed: {e}")
            
            # ✨ NEW v4.2: Additional Providers
            
            # NASA (FREE - Public domain imagery)
            try:
                self.smart_selector.add_provider(
                    "nasa",
                    NASAProvider()
                )
            except Exception as e:
                print(f"[WARN] NASA init failed: {e}")
            
            # Flickr API (if key provided)
            if flickr_key:
                try:
                    self.smart_selector.add_provider(
                        "flickr",
                        FlickrProvider(flickr_key)
                    )
                except Exception as e:
                    print(f"[WARN] Flickr init failed: {e}")
            
            # Library of Congress (FREE - Public domain)
            try:
                self.smart_selector.add_provider(
                    "loc",
                    LibraryOfCongressProvider()
                )
            except Exception as e:
                print(f"[WARN] Library of Congress init failed: {e}")
            
            # Wikimedia Commons (FREE - Wikipedia media)
            try:
                self.smart_selector.add_provider(
                    "wikimedia",
                    WikimediaCommonsProvider()
                )
            except Exception as e:
                print(f"[WARN] Wikimedia Commons init failed: {e}")
            
            # Smithsonian (FREE - Museum collections)
            try:
                self.smart_selector.add_provider(
                    "smithsonian",
                    SmithsonianProvider()
                )
            except Exception as e:
                print(f"[WARN] Smithsonian init failed: {e}")
            
            # Metropolitan Museum (FREE - Art collection)
            try:
                self.smart_selector.add_provider(
                    "metmuseum",
                    MetMuseumProvider()
                )
            except Exception as e:
                print(f"[WARN] Met Museum init failed: {e}")
            
            # Europeana (if key provided - European cultural heritage)
            if europeana_key:
                try:
                    self.smart_selector.add_provider(
                        "europeana",
                        EuropeanaProvider(europeana_key)
                    )
                except Exception as e:
                    print(f"[WARN] Europeana init failed: {e}")
            
            # FlagsAPI (FREE - Country flags)
            try:
                self.smart_selector.add_provider(
                    "flags",
                    FlagsAPIProvider()
                )
            except Exception as e:
                print(f"[WARN] FlagsAPI init failed: {e}")
            
            if not self.smart_selector.providers:
                raise APIError("Không có image provider nào được cấu hình!")
            
            print(f"[✓] Smart Image Selector initialized with {len(self.smart_selector.providers)} providers")
    
    def get_image_url(self, vocabulary: str, definition: str) -> str:
        """
        Lấy URL ảnh tốt nhất - v4.3 ULTRA-FAST with dual-level caching
        
        Flow:
        1. Check full result cache (FASTEST - O(1) direct return) ✨ NEW
        2. Check keyword cache (FAST - O(1))
        3. Generate keyword từ AI (with fallback chain)
        4. Search images concurrently (all providers in parallel)
        5. If enable_ai_evaluation: Use Gemini Vision to pick best
        6. Cache result for future calls ✨ NEW
        """
        # ⚡ ULTRA-FAST-PATH: Check if we have complete result cached
        result_cache_key = f"result_{vocabulary}|{definition}".lower()
        if hasattr(self, '_result_cache'):
            cached_result = self._result_cache.get(result_cache_key)
            if cached_result:
                return cached_result
        else:
            # ✨ Initialize result cache on first use
            self._result_cache = KeywordCache(max_size=500)
        
        # ⚡ STEP 1: Try keyword cache
        cache_key = self.keyword_cache.make_key(vocabulary, definition)
        cached_keyword = self.keyword_cache.get(cache_key)
        
        if cached_keyword:
            keyword = cached_keyword
        else:
            # STEP 2: Generate keyword từ AI
            try:
                keyword, provider_name = self.ai_provider.generate_keyword(
                    vocabulary, 
                    definition
                )
                self.keyword_cache.set(cache_key, keyword)
            except AIProviderError as e:
                raise APIError(f"Keyword generation failed: {e}")
        
        # ⚡ STEP 3: Smart image search (concurrent, with timeout)
        if not (self.enable_smart_selection and self.smart_selector):
            raise APIError("Image selection disabled")
        
        try:
            # ✨ Reduced candidates: 1 if no eval, 5 if eval (was 8 - faster)
            top_n = 5 if (self.enable_ai_evaluation and self.image_evaluator) else 1
            candidate_urls = self.smart_selector.search_smart(keyword, top_n=top_n)
            
            if not candidate_urls:
                raise APIError(f"No images found for: '{keyword}'")
            
            # ✨ Fast path: if only 1 candidate or no evaluator, return immediately
            if len(candidate_urls) == 1 or not (self.enable_ai_evaluation and self.image_evaluator):
                best_url = candidate_urls[0]
            else:
                # ⚡ STEP 4: AI Evaluation (if enabled and multiple candidates)
                try:
                    best_url = self.image_evaluator.evaluate_images(
                        candidate_urls,
                        vocabulary,
                        definition
                    )
                except AIProviderError:
                    # ⚡ Fallback: return first from smart selection
                    best_url = candidate_urls[0]
            
            # ✨ Cache the full result for future calls
            self._result_cache.set(result_cache_key, best_url)
            return best_url
        
        except ImageProviderError as e:
            raise APIError(f"Image search failed: {e}")

